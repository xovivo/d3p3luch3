var $j = jQuery.noConflict();
